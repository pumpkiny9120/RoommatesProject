package com.oose2013.group7.roommates.common.interfaces;

public interface Event {

}
